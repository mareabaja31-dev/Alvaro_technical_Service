//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-EsRS8xfd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/contacto",
			"/cv",
			"/experiencia",
			"/gracias",
			"/habilidades",
			"/sobre-mi"
		],
		preloads: ["/assets/index-Bk7eWkKc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bk7eWkKc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D90khO7g.js", "/assets/pages-DQ3PITHN.js"]
	},
	"/contacto": {
		filePath: "/workspace/src/routes/contacto.tsx",
		children: void 0,
		preloads: ["/assets/contacto-hbyFZoIn.js", "/assets/pages-DQ3PITHN.js"]
	},
	"/cv": {
		filePath: "/workspace/src/routes/cv.tsx",
		children: void 0,
		preloads: ["/assets/cv-CM1ha0g3.js"]
	},
	"/experiencia": {
		filePath: "/workspace/src/routes/experiencia.tsx",
		children: void 0,
		preloads: ["/assets/experiencia-P58mvqUX.js", "/assets/pages-DQ3PITHN.js"]
	},
	"/gracias": {
		filePath: "/workspace/src/routes/gracias.tsx",
		children: void 0,
		preloads: ["/assets/gracias-Bsi5KFXg.js", "/assets/pages-DQ3PITHN.js"]
	},
	"/habilidades": {
		filePath: "/workspace/src/routes/habilidades.tsx",
		children: void 0,
		preloads: ["/assets/habilidades-BTnvAFla.js", "/assets/pages-DQ3PITHN.js"]
	},
	"/sobre-mi": {
		filePath: "/workspace/src/routes/sobre-mi.tsx",
		children: void 0,
		preloads: ["/assets/sobre-mi-DGkA8Fw2.js", "/assets/pages-DQ3PITHN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
