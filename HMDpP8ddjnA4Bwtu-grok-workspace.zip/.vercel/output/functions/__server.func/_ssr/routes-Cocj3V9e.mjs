import { a as Inicio } from "./pages-ZqDcYkLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cocj3V9e.js
var SplitComponent = Inicio;
//#endregion
export { SplitComponent as component };
