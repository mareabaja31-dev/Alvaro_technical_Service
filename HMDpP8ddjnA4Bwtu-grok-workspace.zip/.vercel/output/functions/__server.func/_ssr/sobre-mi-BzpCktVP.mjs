import { o as SobreMi } from "./pages-ZqDcYkLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sobre-mi-BzpCktVP.js
var SplitComponent = SobreMi;
//#endregion
export { SplitComponent as component };
