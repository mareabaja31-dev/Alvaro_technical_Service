import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route$5 } from "./router-B0eKM3o6.mjs";
import { t as Contacto } from "./pages-ZqDcYkLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contacto-D7ajpVmN.js
var import_jsx_runtime = require_jsx_runtime();
function ContactoPage() {
	const { asunto } = Route$5.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contacto, { initialSubject: asunto ?? "" });
}
//#endregion
export { ContactoPage as component };
