import { r as Gracias } from "./pages-ZqDcYkLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gracias-FFcAQcv2.js
var SplitComponent = Gracias;
//#endregion
export { SplitComponent as component };
