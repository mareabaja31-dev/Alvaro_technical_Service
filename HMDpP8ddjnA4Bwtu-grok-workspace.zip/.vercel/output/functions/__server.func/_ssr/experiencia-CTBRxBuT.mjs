import { n as Experiencia } from "./pages-ZqDcYkLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/experiencia-CTBRxBuT.js
var SplitComponent = Experiencia;
//#endregion
export { SplitComponent as component };
