import { i as __toESM } from "../_runtime.mjs";
import { C as useRouter, S as useNavigate, X as require_react, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, p as HeadContent, v as lazyRouteComponent, w as require_jsx_runtime, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as Download, i as TriangleAlert, t as X, u as Menu } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-B0eKM3o6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var SCENES = [
	{
		id: "inicio",
		src: "/photos/hero.jpg",
		position: "center center"
	},
	{
		id: "sobre-mi",
		src: "/photos/farm.jpg",
		position: "right center"
	},
	{
		id: "experiencia",
		src: "/photos/hero.jpg",
		position: "center top"
	},
	{
		id: "habilidades",
		src: "/photos/code.jpg",
		position: "right center"
	},
	{
		id: "contacto",
		src: "/photos/earth.jpg",
		position: "left center"
	},
	{
		id: "gracias",
		src: "/photos/thanks.jpg",
		position: "center center"
	}
];
var VEIL = [
	"inicio",
	"sobre-mi",
	"experiencia",
	"habilidades",
	"contacto",
	"gracias"
];
var INTENSITY = {
	inicio: .72,
	"sobre-mi": .8,
	experiencia: 1,
	habilidades: .9,
	contacto: .85,
	gracias: .62
};
function Background({ page }) {
	const svgRef = (0, import_react.useRef)(null);
	const shiftRef = (0, import_react.useRef)(null);
	const intensityRef = (0, import_react.useRef)(INTENSITY[page]);
	intensityRef.current = INTENSITY[page];
	(0, import_react.useEffect)(() => {
		const svg = svgRef.current;
		if (!svg) return;
		const ns = "http://www.w3.org/2000/svg";
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const gradId = `cursor-glow-${Math.random().toString(36).slice(2, 8)}`;
		const defs = document.createElementNS(ns, "defs");
		const grad = document.createElementNS(ns, "radialGradient");
		grad.id = gradId;
		const stopA = document.createElementNS(ns, "stop");
		stopA.setAttribute("offset", "0%");
		stopA.setAttribute("stop-color", "rgb(0, 242, 195)");
		stopA.setAttribute("stop-opacity", "0.35");
		const stopB = document.createElementNS(ns, "stop");
		stopB.setAttribute("offset", "100%");
		stopB.setAttribute("stop-color", "rgb(0, 242, 195)");
		stopB.setAttribute("stop-opacity", "0");
		grad.append(stopA, stopB);
		defs.append(grad);
		const glow = document.createElementNS(ns, "circle");
		glow.setAttribute("r", "210");
		glow.setAttribute("fill", `url(#${gradId})`);
		glow.setAttribute("opacity", "0");
		svg.append(defs, glow);
		let width = window.innerWidth;
		let height = window.innerHeight;
		const count = width < 720 ? 34 : 68;
		const particles = [];
		for (let i = 0; i < count; i++) {
			const el = document.createElementNS(ns, "circle");
			el.setAttribute("fill", "rgb(214, 255, 244)");
			svg.append(el);
			particles.push({
				x: Math.random() * width,
				y: Math.random() * height,
				vx: (Math.random() - .5) * .38,
				vy: (Math.random() - .5) * .38,
				r: Math.random() * 1.6 + .7,
				el
			});
		}
		const linePool = [];
		for (let i = 0; i < 240; i++) {
			const line = document.createElementNS(ns, "line");
			line.setAttribute("stroke", "rgb(0, 242, 195)");
			line.style.display = "none";
			svg.append(line);
			linePool.push(line);
		}
		const mouse = {
			x: width * .72,
			y: height * .4,
			on: false
		};
		let raf = 0;
		const resize = () => {
			width = window.innerWidth;
			height = window.innerHeight;
			svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
		};
		const frame = () => {
			const intensity = intensityRef.current;
			if (!reduce) for (const p of particles) {
				if (mouse.on) {
					const dx = mouse.x - p.x;
					const dy = mouse.y - p.y;
					const dist = Math.hypot(dx, dy) || 1;
					if (dist < 210) {
						const pull = (210 - dist) / 210 * .05;
						p.vx += dx / dist * pull;
						p.vy += dy / dist * pull;
					}
				}
				p.vx *= .985;
				p.vy *= .985;
				if (Math.hypot(p.vx, p.vy) < .08) {
					p.vx += (Math.random() - .5) * .05;
					p.vy += (Math.random() - .5) * .05;
				}
				p.x += p.vx;
				p.y += p.vy;
				if (p.x < -12) p.x = width + 12;
				if (p.x > width + 12) p.x = -12;
				if (p.y < -12) p.y = height + 12;
				if (p.y > height + 12) p.y = -12;
			}
			const reach = width < 720 ? 108 : 136;
			let slot = 0;
			for (let i = 0; i < particles.length; i++) {
				const a = particles[i];
				if (!a) continue;
				a.el.setAttribute("cx", a.x.toFixed(1));
				a.el.setAttribute("cy", a.y.toFixed(1));
				a.el.setAttribute("r", a.r.toFixed(2));
				a.el.setAttribute("opacity", (.85 * intensity).toFixed(2));
				for (let j = i + 1; j < particles.length; j++) {
					const b = particles[j];
					if (!b || slot >= linePool.length) continue;
					const dist = Math.hypot(a.x - b.x, a.y - b.y);
					if (dist < reach) {
						const line = linePool[slot];
						if (!line) continue;
						slot += 1;
						line.style.display = "";
						line.setAttribute("x1", a.x.toFixed(1));
						line.setAttribute("y1", a.y.toFixed(1));
						line.setAttribute("x2", b.x.toFixed(1));
						line.setAttribute("y2", b.y.toFixed(1));
						line.setAttribute("stroke-opacity", ((1 - dist / reach) * .45 * intensity).toFixed(3));
					}
				}
				if (mouse.on && slot < linePool.length) {
					const dist = Math.hypot(a.x - mouse.x, a.y - mouse.y);
					if (dist < 170) {
						const line = linePool[slot];
						if (line) {
							slot += 1;
							line.style.display = "";
							line.setAttribute("x1", a.x.toFixed(1));
							line.setAttribute("y1", a.y.toFixed(1));
							line.setAttribute("x2", mouse.x.toFixed(1));
							line.setAttribute("y2", mouse.y.toFixed(1));
							line.setAttribute("stroke-opacity", ((1 - dist / 170) * .7 * intensity).toFixed(3));
						}
					}
				}
			}
			for (let i = slot; i < linePool.length; i++) {
				const line = linePool[i];
				if (line) line.style.display = "none";
			}
			glow.setAttribute("cx", mouse.x.toFixed(1));
			glow.setAttribute("cy", mouse.y.toFixed(1));
			glow.setAttribute("opacity", mouse.on ? (.85 * intensity).toFixed(2) : "0");
			raf = window.requestAnimationFrame(frame);
		};
		const onMove = (x, y) => {
			mouse.x = x;
			mouse.y = y;
			mouse.on = true;
			const shift = shiftRef.current;
			if (shift && !reduce) {
				shift.style.setProperty("--px", ((x / window.innerWidth - .5) * 2).toFixed(3));
				shift.style.setProperty("--py", ((y / window.innerHeight - .5) * 2).toFixed(3));
			}
		};
		const onPointer = (event) => onMove(event.clientX, event.clientY);
		const onTouch = (event) => {
			const touch = event.touches[0];
			if (touch) onMove(touch.clientX, touch.clientY);
		};
		const onLeave = () => {
			mouse.on = false;
		};
		resize();
		raf = window.requestAnimationFrame(frame);
		window.addEventListener("resize", resize);
		window.addEventListener("pointermove", onPointer, { passive: true });
		window.addEventListener("touchmove", onTouch, { passive: true });
		window.addEventListener("pointerleave", onLeave);
		return () => {
			window.cancelAnimationFrame(raf);
			svg.replaceChildren();
			window.removeEventListener("resize", resize);
			window.removeEventListener("pointermove", onPointer);
			window.removeEventListener("touchmove", onTouch);
			window.removeEventListener("pointerleave", onLeave);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed inset-0 z-0 overflow-hidden bg-bg",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: shiftRef,
				className: "photo-shift absolute inset-0",
				children: SCENES.map((scene) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: scene.src,
					alt: "",
					className: `absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${page === scene.id ? "opacity-100" : "opacity-0"}`,
					style: { objectPosition: scene.position }
				}, scene.id))
			}),
			VEIL.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `veil veil-${id} ${page === id ? "opacity-100" : "opacity-0"}` }, id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				ref: svgRef,
				className: "absolute inset-0 h-full w-full"
			})
		]
	});
}
var PAGE_ORDER = [
	"inicio",
	"sobre-mi",
	"experiencia",
	"habilidades",
	"contacto",
	"gracias"
];
var NAV = [
	{
		id: "inicio",
		label: "Inicio",
		href: "/"
	},
	{
		id: "sobre-mi",
		label: "Sobre mí",
		href: "/sobre-mi"
	},
	{
		id: "experiencia",
		label: "Experiencia",
		href: "/experiencia"
	},
	{
		id: "habilidades",
		label: "Habilidades",
		href: "/habilidades"
	},
	{
		id: "contacto",
		label: "Contacto",
		href: "/contacto"
	}
];
function pageFromPath(pathname) {
	switch (pathname.replace(/\/$/, "") || "/") {
		case "/sobre-mi": return "sobre-mi";
		case "/experiencia": return "experiencia";
		case "/habilidades": return "habilidades";
		case "/contacto": return "contacto";
		case "/gracias": return "gracias";
		default: return "inicio";
	}
}
var PROFILE = {
	name: "Álvaro García-Aparicio Rey",
	kicker: "Mecánica · Electrónica · Informática",
	phoneDisplay: "+34 659 597 291",
	phoneHref: "tel:+34659597291",
	email: "alvarogar31@gmail.com",
	linkedin: "https://www.linkedin.com/in/alvaro-garcia-aparicio-rey-576821290",
	whatsapp: "https://wa.me/34659597291"
};
var SUBJECTS = [
	"Oportunidad laboral",
	"Electromecánica / Automoción",
	"Montaje eólico / Electricidad",
	"Software / Automatización / IA",
	"Otro asunto"
];
var AREAS = [
	{
		id: "auto",
		title: "Electromecánico de Automóviles & Automatización",
		image: "/photos/auto.jpg",
		alt: "Deportivo negro en taller con diagnóstico electrónico",
		subject: "Electromecánica / Automoción",
		points: [
			"Reparaciones y Mantenimiento",
			"Adaptaciones Técnicas",
			"Automatización de Vehículos y Procesos de Negocio"
		],
		detail: "Trabajo de electromecánica sobre el vehículo y sobre el proceso: diagnosis, reparación, mantenimiento y adaptaciones técnicas. Cuando un paso se repite, lo automatizo para que el taller o el negocio gane fiabilidad y tiempo."
	},
	{
		id: "eolica",
		title: "Técnico de Montaje de Turbinas Eólicas (Electricista)",
		image: "/photos/wind.jpg",
		alt: "Técnico sobre la góndola de un aerogenerador al atardecer",
		subject: "Montaje eólico / Electricidad",
		points: [
			"Montaje de Estructuras",
			"Cableado Industrial Especializado",
			"Trabajos en Altura (PRL)",
			"Verificaciones Eléctricas"
		],
		detail: "Montaje de turbinas en campo, con el oficio de electricista: estructuras, cableado industrial, trabajo en altura con PRL y verificaciones eléctricas antes de dejar la máquina en servicio."
	},
	{
		id: "digital",
		title: "Informática, Desarrollo & Inteligencia Artificial",
		image: "/photos/code.jpg",
		alt: "Puesto de desarrollo con monitores y una red neuronal luminosa",
		subject: "Software / Automatización / IA",
		points: [
			"Desarrollo Web & Frontend/Backend",
			"Python & JavaScript",
			"Automatización de Recursos",
			"Integración de IA"
		],
		detail: "Desarrollo web, Python y JavaScript, automatización de recursos e integración de inteligencia artificial aplicada a un problema concreto: menos tarea manual, más criterio técnico."
	}
];
var TRAITS = [
	{
		title: "Versatilidad técnica",
		icon: "layers"
	},
	{
		title: "Resolución de problemas",
		icon: "brain"
	},
	{
		title: "Trabajo en equipo",
		icon: "users"
	},
	{
		title: "Orientación a resultados",
		icon: "target"
	}
];
var SKILL_GROUPS = [{
	id: "mech",
	title: "Electromecánica & Mantenimiento",
	image: "/photos/mech.jpg",
	alt: "Detalle de componentes mecánicos de un motor",
	points: [
		"Diagnosis",
		"Reparaciones",
		"Mantenimiento Preventivo/Correctivo",
		"Adaptaciones",
		"Automatización Vehicular"
	]
}, {
	id: "wind",
	title: "Energía Eólica & Electricidad",
	image: "/photos/farm.jpg",
	alt: "Parque eólico al anochecer",
	points: [
		"Montaje de Turbinas",
		"Cableado Industrial",
		"Trabajos en Altura (PRL)",
		"Verificaciones Eléctricas"
	]
}];
var SOFTWARE_SKILLS = {
	left: [
		"Desarrollo Web",
		"Python",
		"JavaScript"
	],
	right: [
		"Automatización de Recursos",
		"Integración de IA",
		"Soporte Técnico"
	]
};
function goTo(navigate, id) {
	if (id === "inicio") navigate({ to: "/" });
	else if (id === "sobre-mi") navigate({ to: "/sobre-mi" });
	else if (id === "experiencia") navigate({ to: "/experiencia" });
	else if (id === "habilidades") navigate({ to: "/habilidades" });
	else if (id === "contacto") navigate({ to: "/contacto" });
	else navigate({ to: "/gracias" });
}
function Shell() {
	const page = pageFromPath(useRouterState({ select: (state) => state.location.pathname }));
	const navigate = useNavigate();
	const scroller = (0, import_react.useRef)(null);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const lock = (0, import_react.useRef)(false);
	const pageRef = (0, import_react.useRef)(page);
	pageRef.current = page;
	(0, import_react.useEffect)(() => {
		setMenu(false);
		scroller.current?.scrollTo({ top: 0 });
	}, [page]);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		const prev = root.style.overflow;
		root.style.overflow = "hidden";
		return () => {
			root.style.overflow = prev;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const sc = () => scroller.current;
		const atEdge = (direction) => {
			const node = sc();
			if (!node) return false;
			const atTop = node.scrollTop <= 1;
			const atBottom = node.scrollTop + node.clientHeight >= node.scrollHeight - 2;
			return direction > 0 ? atBottom : atTop;
		};
		const shift = (direction, force = false) => {
			if (lock.current || menu) return false;
			if (document.querySelector("[data-modal]")) return false;
			if (!force && !atEdge(direction)) return false;
			const next = PAGE_ORDER[PAGE_ORDER.indexOf(pageRef.current) + direction];
			if (!next) return false;
			lock.current = true;
			window.setTimeout(() => {
				lock.current = false;
			}, 700);
			goTo(navigate, next);
			return true;
		};
		let acc = 0;
		const onWheel = (event) => {
			if (event.target?.closest("textarea, input, select, [data-modal]")) return;
			const node = sc();
			if (!node) return;
			const atTop = node.scrollTop <= 1;
			const atBottom = node.scrollTop + node.clientHeight >= node.scrollHeight - 2;
			const down = event.deltaY > 0;
			if (down && !atBottom || !down && !atTop) {
				acc = 0;
				return;
			}
			if (lock.current) {
				event.preventDefault();
				return;
			}
			acc += event.deltaY;
			if (Math.abs(acc) < 70) return;
			event.preventDefault();
			acc = 0;
			shift(down ? 1 : -1);
		};
		let startY = 0;
		let startScroll = 0;
		const onTouchStart = (event) => {
			const touch = event.touches[0];
			if (!touch) return;
			startY = touch.clientY;
			startScroll = sc()?.scrollTop ?? 0;
		};
		const onTouchEnd = (event) => {
			const touch = event.changedTouches[0];
			const node = sc();
			if (!touch || !node) return;
			if (Math.abs(node.scrollTop - startScroll) > 8) return;
			const dy = startY - touch.clientY;
			if (Math.abs(dy) < 64) return;
			shift(dy > 0 ? 1 : -1);
		};
		const onKey = (event) => {
			const target = event.target;
			if (target && [
				"INPUT",
				"TEXTAREA",
				"SELECT"
			].includes(target.tagName)) return;
			if (event.key === "Escape") setMenu(false);
			if (event.key === "ArrowDown" || event.key === "PageDown") {
				if (shift(1, true)) event.preventDefault();
			}
			if (event.key === "ArrowUp" || event.key === "PageUp") {
				if (shift(-1, true)) event.preventDefault();
			}
		};
		window.addEventListener("wheel", onWheel, { passive: false });
		window.addEventListener("touchstart", onTouchStart, { passive: true });
		window.addEventListener("touchend", onTouchEnd, { passive: true });
		window.addEventListener("keydown", onKey);
		return () => {
			window.removeEventListener("wheel", onWheel);
			window.removeEventListener("touchstart", onTouchStart);
			window.removeEventListener("touchend", onTouchEnd);
			window.removeEventListener("keydown", onKey);
		};
	}, [menu, navigate]);
	const label = NAV.find((item) => item.id === page)?.label ?? "Gracias";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Background, { page }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "site-header fixed inset-x-0 top-0 z-40 border-b border-line/80 bg-bg/55 backdrop-blur-xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-full max-w-7xl items-center justify-between gap-4 px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "min-w-0 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-extrabold text-fg sm:text-base",
							children: PROFILE.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "kicker hidden text-accent sm:block",
							children: PROFILE.kicker
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden items-center gap-7 lg:flex",
						"aria-label": "Secciones",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.href,
							"aria-current": page === item.id ? "page" : void 0,
							className: `nav-link ${page === item.id ? "is-active" : ""}`,
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/cv",
							className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-accent/70 px-3 text-xs font-extrabold text-accent transition hover:bg-accent hover:text-ink sm:px-4 sm:text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Descargar CV"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full border border-line text-fg lg:hidden",
							"aria-expanded": menu,
							"aria-label": menu ? "Cerrar menú" : "Abrir menú",
							onClick: () => setMenu((open) => !open),
							children: menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})]
					})
				]
			})
		}),
		menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-30 bg-bg/95 px-8 pt-28 lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-col gap-2",
				"aria-label": "Secciones",
				children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.href,
					className: "min-h-12 text-2xl font-extrabold text-fg",
					"aria-current": page === item.id ? "page" : void 0,
					children: item.label
				}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/gracias",
					className: "min-h-12 text-2xl font-extrabold text-muted",
					children: "Gracias"
				})]
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "scroller",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-in page-frame",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "sr-only",
					"aria-live": "polite",
					children: ["Sección ", label]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})]
			}, page)
		})
	] });
}
var styles_default = "/assets/styles-cnJ3fHCU.css";
var APP_NAME = "Álvaro García-Aparicio Rey — Mecánica, Electrónica e Informática";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Portfolio profesional de Álvaro García-Aparicio Rey: electromecánica, tecnología eólica, desarrollo de software e inteligencia artificial."
			},
			{
				name: "theme-color",
				content: "#030812"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:ital,wght@0,400;0,500;0,600;0,700;0,800;1,500;1,600&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootComponent
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "es",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function AppFrame() {
	if (useRouterState({ select: (state) => state.location.pathname }) === "/cv") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
var $$splitComponentImporter$6 = () => import("./routes-Cocj3V9e.mjs");
var Route$6 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Inicio — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./contacto-D7ajpVmN.mjs");
var Route$5 = createFileRoute("/contacto")({
	validateSearch: (search) => {
		if (typeof search.asunto === "string" && search.asunto.length > 0) return { asunto: search.asunto };
		return {};
	},
	head: () => ({ meta: [{ title: "Contacto — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./cv-DviGShJH.mjs");
var Route$4 = createFileRoute("/cv")({
	head: () => ({ meta: [{ title: "CV — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./experiencia-CTBRxBuT.mjs");
var Route$3 = createFileRoute("/experiencia")({
	head: () => ({ meta: [{ title: "Experiencia — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./gracias-FFcAQcv2.mjs");
var Route$2 = createFileRoute("/gracias")({
	head: () => ({ meta: [{ title: "Gracias — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./habilidades-CuQku5uS.mjs");
var Route$1 = createFileRoute("/habilidades")({
	head: () => ({ meta: [{ title: "Habilidades — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./sobre-mi-BzpCktVP.mjs");
var Route = createFileRoute("/sobre-mi")({
	head: () => ({ meta: [{ title: "Sobre mí — Álvaro García-Aparicio Rey" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	ContactoRoute: Route$5.update({
		id: "/contacto",
		path: "/contacto",
		getParentRoute: () => Route$7
	}),
	CvRoute: Route$4.update({
		id: "/cv",
		path: "/cv",
		getParentRoute: () => Route$7
	}),
	ExperienciaRoute: Route$3.update({
		id: "/experiencia",
		path: "/experiencia",
		getParentRoute: () => Route$7
	}),
	GraciasRoute: Route$2.update({
		id: "/gracias",
		path: "/gracias",
		getParentRoute: () => Route$7
	}),
	HabilidadesRoute: Route$1.update({
		id: "/habilidades",
		path: "/habilidades",
		getParentRoute: () => Route$7
	}),
	SobreMiRoute: Route.update({
		id: "/sobre-mi",
		path: "/sobre-mi",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { SKILL_GROUPS as a, TRAITS as c, PROFILE as i, Route$5 as n, SOFTWARE_SKILLS as o, AREAS as r, SUBJECTS as s, router_exports as t };
