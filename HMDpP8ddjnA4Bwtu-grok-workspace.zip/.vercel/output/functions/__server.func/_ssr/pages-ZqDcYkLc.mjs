import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, d as require_react_dom, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Code, a as Target, b as ArrowUp, c as Phone, d as Mail, f as Linkedin, g as Cpu, l as Mouse, m as ExternalLink, n as Wind, o as Settings, p as Layers, r as Users, s as Send, t as X, v as Car, x as ArrowDown, y as Brain } from "../_libs/lucide-react.mjs";
import { a as SKILL_GROUPS, c as TRAITS, i as PROFILE, o as SOFTWARE_SKILLS, r as AREAS, s as SUBJECTS } from "./router-B0eKM3o6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pages-ZqDcYkLc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = require_react_dom();
function WhatsAppIcon({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.04 2C6.58 2 2.15 6.4 2.15 11.83c0 1.74.46 3.44 1.34 4.94L2 22l5.39-1.4a10 10 0 0 0 4.65 1.18h.01c5.46 0 9.89-4.4 9.89-9.83C21.94 6.4 17.5 2 12.04 2zm5.76 14.15c-.24.68-1.4 1.3-1.94 1.38-.5.08-1.12.11-1.81-.11-.42-.14-.95-.31-1.64-.6-2.88-1.24-4.76-4.14-4.9-4.33-.14-.19-1.16-1.54-1.16-2.94s.73-2.08 1-2.37c.24-.28.64-.41 1.02-.41.12 0 .23 0 .33.01.3.01.44.03.64.5.24.57.82 1.98.89 2.12.07.14.12.31.02.49-.09.19-.14.31-.28.48-.14.17-.29.37-.42.5-.14.14-.28.28-.12.55.16.26.7 1.16 1.51 1.88 1.04.92 1.91 1.21 2.18 1.35.27.14.43.12.59-.07.16-.19.68-.79.86-1.06.18-.28.36-.23.6-.14.24.09 1.54.73 1.8.86.27.14.44.19.51.3.07.12.07.67-.17 1.35z" })
	});
}
function SocialRow() {
	const items = [
		{
			label: "LinkedIn",
			href: PROFILE.linkedin,
			external: true,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "size-5" })
		},
		{
			label: "WhatsApp",
			href: PROFILE.whatsapp,
			external: true,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "size-5" })
		},
		{
			label: "Llamar",
			href: PROFILE.phoneHref,
			external: false,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-6",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: item.href,
			...item.external ? {
				target: "_blank",
				rel: "noreferrer"
			} : {},
			className: "group flex min-w-16 flex-col items-center gap-2 text-xs font-semibold text-muted transition hover:text-accent",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-12 place-items-center rounded-full border border-line bg-bg/50 text-fg transition group-hover:border-accent group-hover:text-accent",
				children: item.icon
			}), item.label]
		}, item.label))
	});
}
var traitIcon = {
	layers: Layers,
	brain: Brain,
	users: Users,
	target: Target
};
function Inicio() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-1 items-center px-5 py-8 sm:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid w-full max-w-7xl items-center gap-10 lg:grid-cols-[1.45fr_0.55fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-semibold italic text-accent",
							children: "Hola, soy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 text-4xl font-extrabold tracking-tight text-fg sm:text-5xl lg:text-6xl",
							children: PROFILE.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker mt-4 text-accent",
							children: PROFILE.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
							children: "Un perfil multidisciplinar que combina ingeniería técnica sobre el terreno con soluciones digitales avanzadas."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/experiencia",
							className: "btn-glow mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-7 text-sm font-extrabold text-ink transition hover:-translate-y-0.5",
							children: ["Explorar mi portfolio", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialRow, {})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-4 lg:justify-self-end",
					children: [
						"Automoción",
						"Energía eólica",
						"Tecnología",
						"IA"
					].map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 text-sm font-extrabold tracking-widest text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rotate-45 bg-accent" }), tag.toUpperCase()]
					}, tag))
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/sobre-mi",
			className: "flex flex-col items-center gap-1 pb-5 text-xs font-medium text-muted transition hover:text-accent",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mouse, { className: "floaty size-5 text-accent" }), "Desliza para explorar"]
		})]
	});
}
function SobreMi() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-1 items-center px-5 py-10 sm:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid w-full max-w-7xl items-center gap-12 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker text-accent",
					children: "Sobre mí"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-3 text-3xl font-extrabold leading-tight text-fg sm:text-5xl",
					children: [
						"Más que un perfil técnico,",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"una visión completa."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xl text-sm leading-relaxed text-muted sm:text-base",
					children: "Soy una persona apasionada por la tecnología, la mecánica y la innovación. Mi formación y experiencia me permiten abordar proyectos complejos en distintos entornos, desde el montaje de turbinas eólicas y la electromecánica industrial, hasta el desarrollo de soluciones informáticas y la integración de Inteligencia Artificial."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 space-y-4",
					children: TRAITS.map((trait) => {
						const Icon = traitIcon[trait.icon];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 place-items-center rounded-full border border-accent/40 bg-accent/10 text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-bold text-fg",
								children: trait.title
							})]
						}, trait.title);
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hud mx-auto w-full max-w-md overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/photos/about.jpg",
							alt: "Técnico de energía eólica frente a un parque de turbinas al atardecer",
							className: "aspect-3/4 w-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "glass absolute right-4 bottom-4 left-4 border-l-4 border-l-accent px-4 py-3 text-sm font-bold text-accent",
							children: "De la ingeniería en el campo a la innovación digital."
						})
					]
				})
			})]
		})
	});
}
var areaIcon = {
	auto: Car,
	eolica: Wind,
	digital: Cpu
};
function Experiencia() {
	const [open, setOpen] = (0, import_react.useState)(null);
	const closeRef = (0, import_react.useRef)(null);
	const titleId = (0, import_react.useId)();
	(0, import_react.useEffect)(() => {
		if (!open) return;
		closeRef.current?.focus();
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(null);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 items-center px-5 py-10 sm:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker text-accent",
					children: "Experiencia profesional"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-3 max-w-3xl text-3xl font-extrabold leading-tight text-fg sm:text-5xl",
					children: [
						"Tres áreas, un mismo objetivo:",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"resolver, mejorar, innovar."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-5 md:grid-cols-3",
					children: AREAS.map((area) => {
						const Icon = areaIcon[area.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "glass glass-hover flex flex-col overflow-hidden transition",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-44",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: area.image,
									alt: area.alt,
									className: "h-full w-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute bottom-3 left-3 grid size-10 place-items-center rounded-lg bg-bg/80 text-accent ring-1 ring-accent/40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-1 flex-col p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-bold leading-snug text-fg",
										children: area.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-4 flex-1 space-y-2 text-sm text-muted",
										children: area.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1 shrink-0 rounded-full bg-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: point })]
										}, point))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setOpen(area),
										className: "mt-5 inline-flex min-h-11 items-center text-sm font-bold text-accent",
										children: "Ver más →"
									})
								]
							})]
						}, area.id);
					})
				})
			]
		}), open && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"data-modal": true,
			className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/75 p-4 backdrop-blur-sm sm:items-center",
			onClick: () => setOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": titleId,
				className: "glass max-h-[88vh] w-full max-w-3xl overflow-y-auto",
				onClick: (event) => event.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-56 sm:h-72",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: open.image,
						alt: "",
						className: "h-full w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						ref: closeRef,
						type: "button",
						onClick: () => setOpen(null),
						"aria-label": "Cerrar",
						className: "absolute top-3 right-3 grid size-11 place-items-center rounded-full bg-bg/80 text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							id: titleId,
							className: "text-2xl font-extrabold text-fg",
							children: open.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted sm:text-base",
							children: open.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 space-y-2 text-sm text-fg",
							children: open.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1 shrink-0 rounded-full bg-accent" }), point]
							}, point))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contacto",
							search: { asunto: open.subject },
							className: "btn-glow mt-6 inline-flex min-h-12 items-center rounded-full bg-accent px-6 text-sm font-extrabold text-ink",
							children: "Contactar sobre esto"
						})
					]
				})]
			})
		}), document.body) : null]
	});
}
function SkillCard({ icon, title, points, image, alt }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "glass relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: image,
				alt,
				className: "absolute inset-0 h-full w-full object-cover opacity-45"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-bg via-bg/85 to-bg/25" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex gap-4 p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 shrink-0 place-items-center rounded-xl border border-accent/40 bg-bg/60 text-accent",
					children: icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-bold text-fg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-1.5 text-sm text-muted",
					children: points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", point] }, point))
				})] })]
			})
		]
	});
}
function Habilidades() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-1 items-center px-5 py-10 sm:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-7xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker text-accent",
					children: "Habilidades y competencias"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-3 text-3xl font-extrabold leading-tight text-fg sm:text-5xl",
					children: [
						"Conocimiento técnico,",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"experiencia real."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 grid gap-5 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillCard, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-6" }),
						title: SKILL_GROUPS[0].title,
						points: SKILL_GROUPS[0].points,
						image: SKILL_GROUPS[0].image,
						alt: SKILL_GROUPS[0].alt
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillCard, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wind, { className: "size-6" }),
						title: SKILL_GROUPS[1].title,
						points: SKILL_GROUPS[1].points,
						image: SKILL_GROUPS[1].image,
						alt: SKILL_GROUPS[1].alt
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "glass mt-5 grid overflow-hidden md:grid-cols-[1.2fr_0.8fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-4 p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-12 shrink-0 place-items-center rounded-xl border border-accent/40 bg-accent/10 text-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Code, { className: "size-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-bold text-fg",
							children: "Informática & Software"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-4 text-sm text-muted sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1.5",
								children: SOFTWARE_SKILLS.left.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", item] }, item))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1.5",
								children: SOFTWARE_SKILLS.right.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", item] }, item))
							})]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-h-40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/photos/laptop.jpg",
							alt: "Portátil con código en un escritorio oscuro",
							className: "absolute inset-0 h-full w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-bg via-bg/20 to-transparent" })]
					})]
				})
			]
		})
	});
}
function Contacto({ initialSubject = "" }) {
	const [subject, setSubject] = (0, import_react.useState)(initialSubject);
	const [fileName, setFileName] = (0, import_react.useState)("Ningún archivo seleccionado");
	const [fileError, setFileError] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	const [mailto, setMailto] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (initialSubject) setSubject(initialSubject);
	}, [initialSubject]);
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const name = String(data.get("name") ?? "").trim();
		const email = String(data.get("email") ?? "").trim();
		const message = String(data.get("message") ?? "").trim();
		const file = data.get("attachment")?.name;
		const chosen = subject || "Contacto desde el portfolio";
		const body = [
			`Nombre: ${name}`,
			`Email: ${email}`,
			`Asunto: ${chosen}`,
			"",
			message,
			"",
			file ? `Archivo que quiero adjuntar: ${file}` : "Sin archivo adjunto."
		].join("\n");
		const href = `mailto:${PROFILE.email}?subject=${encodeURIComponent(chosen)}&body=${encodeURIComponent(body)}`;
		setMailto(href);
		setSent(true);
		window.location.href = href;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-1 items-center px-5 py-10 sm:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid w-full max-w-7xl items-start gap-12 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker text-accent",
						children: "Contacto"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-3xl font-extrabold leading-tight text-fg sm:text-5xl",
						children: "Hablemos de tu próximo proyecto."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md text-sm leading-relaxed text-muted sm:text-base",
						children: "¿Tienes una oportunidad, un proyecto o simplemente quieres saber más? Estoy disponible para cualquier consulta."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: PROFILE.phoneHref,
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-full border border-accent/40 text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold tracking-wider text-muted uppercase",
									children: "Teléfono"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold text-fg",
									children: PROFILE.phoneDisplay
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `mailto:${PROFILE.email}`,
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-full border border-accent/40 text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold tracking-wider text-muted uppercase",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold text-fg",
									children: PROFILE.email
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: PROFILE.linkedin,
								target: "_blank",
								rel: "noreferrer",
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-full border border-accent/40 text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold tracking-wider text-muted uppercase",
									children: "LinkedIn"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold text-fg",
									children: "Ver perfil profesional"
								})] })]
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "glass p-5 sm:p-8",
					children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-8 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker text-accent",
								children: "Mensaje preparado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-2xl font-extrabold text-fg",
								children: "Tu correo está listo para enviarse."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted",
								children: "Se abre el programa de correo con el mensaje dirigido a Álvaro. Si llevas un archivo, adjúntalo allí antes de enviar. Si no se abrió solo, usa el botón."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: mailto,
								className: "btn-glow mt-6 inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-6 text-sm font-extrabold text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Abrir correo"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setSent(false),
								className: "mt-4 block w-full text-sm font-semibold text-muted hover:text-accent",
								children: "Escribir otro mensaje"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 md:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-xs font-bold text-muted",
									children: ["Nombre completo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										name: "name",
										autoComplete: "name",
										placeholder: "Tu nombre completo",
										className: "field mt-1"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-xs font-bold text-muted",
									children: ["Correo electrónico", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "email",
										name: "email",
										autoComplete: "email",
										placeholder: "tu@email.com",
										className: "field mt-1"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-bold text-muted",
								children: ["Asunto / Área de interés", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "subject",
									value: subject,
									onChange: (event) => setSubject(event.target.value),
									className: "field mt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Selecciona una opción"
									}), SUBJECTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item,
										children: item
									}, item))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-bold text-muted",
								children: ["Mensaje", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									required: true,
									name: "message",
									rows: 4,
									placeholder: "Escribe tu mensaje...",
									className: "field mt-1 resize-y"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-muted",
									children: "Adjuntar archivo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: "PDF, imágenes, especificaciones... (Máx. 10 MB)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "inline-flex min-h-11 cursor-pointer items-center rounded-lg border border-accent/40 bg-accent/15 px-4 text-xs font-bold text-accent transition hover:bg-accent hover:text-ink",
										children: ["Seleccionar archivo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											name: "attachment",
											className: "sr-only",
											onChange: (event) => {
												const file = event.target.files?.[0];
												if (!file) {
													setFileName("Ningún archivo seleccionado");
													setFileError("");
													return;
												}
												if (file.size > 10485760) {
													setFileError("El archivo supera 10 MB.");
													setFileName("Ningún archivo seleccionado");
													event.target.value = "";
													return;
												}
												setFileError("");
												setFileName(file.name);
											}
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: fileName
									})]
								}),
								fileError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs font-semibold text-accent",
									children: fileError
								}) : null
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								className: "btn-glow inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-accent text-sm font-extrabold text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Enviar mensaje"]
							})
						]
					})
				})
			})]
		})
	});
}
function Gracias() {
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center px-6 py-16 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-4xl font-extrabold text-fg sm:text-5xl",
						children: PROFILE.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker mt-4 text-accent",
						children: PROFILE.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-10 text-2xl font-bold text-fg sm:text-3xl",
						children: "Gracias por tu tiempo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Si tienes cualquier duda, no dudes en contactarme."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: PROFILE.linkedin,
								target: "_blank",
								rel: "noreferrer",
								"aria-label": "LinkedIn",
								className: "grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: PROFILE.whatsapp,
								target: "_blank",
								rel: "noreferrer",
								"aria-label": "WhatsApp",
								className: "grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: PROFILE.phoneHref,
								"aria-label": "Llamar",
								className: "grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${PROFILE.email}`,
								"aria-label": "Email",
								className: "grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5" })
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				"aria-label": "Volver al inicio",
				className: "absolute right-5 bottom-20 grid size-12 place-items-center rounded-full border border-line bg-bg/70 text-accent transition hover:bg-accent hover:text-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex flex-col items-center justify-between gap-3 border-t border-line/80 px-6 py-4 text-xs text-muted sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					year,
					" ",
					PROFILE.name,
					". Todos los derechos reservados."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: PROFILE.linkedin,
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex items-center gap-1 hover:text-accent",
					children: ["LinkedIn", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })]
				})]
			})
		]
	});
}
//#endregion
export { Inicio as a, Habilidades as i, Experiencia as n, SobreMi as o, Gracias as r, Contacto as t };
