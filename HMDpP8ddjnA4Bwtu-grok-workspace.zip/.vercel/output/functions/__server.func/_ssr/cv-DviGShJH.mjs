import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SKILL_GROUPS, c as TRAITS, i as PROFILE, o as SOFTWARE_SKILLS, r as AREAS } from "./router-B0eKM3o6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cv-DviGShJH.js
var import_jsx_runtime = require_jsx_runtime();
function CvPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print sticky top-0 z-10 border-b border-line bg-bg/90 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center justify-between gap-3 px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-sm font-bold text-accent",
						children: "← Volver al portfolio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => window.print(),
						className: "inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-extrabold text-ink",
						children: "Guardar PDF"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "cv-sheet mx-auto my-8 max-w-3xl bg-fg px-6 py-10 text-ink sm:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "border-b border-ink/15 pb-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl font-extrabold tracking-tight",
								children: PROFILE.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm font-extrabold tracking-widest text-ink/70 uppercase",
								children: PROFILE.kicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: PROFILE.phoneHref,
										children: PROFILE.phoneDisplay
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: `mailto:${PROFILE.email}`,
										children: PROFILE.email
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: PROFILE.linkedin,
										children: "LinkedIn"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: PROFILE.whatsapp,
										children: "WhatsApp"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-extrabold tracking-widest uppercase",
							children: "Perfil"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed",
							children: "Perfil multidisciplinar que combina ingeniería técnica sobre el terreno con soluciones digitales. Experiencia en electromecánica de automóviles, montaje eléctrico de turbinas eólicas y desarrollo de software con automatización e inteligencia artificial."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-extrabold tracking-widest uppercase",
							children: "Áreas profesionales"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-4",
							children: AREAS.map((area) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-bold",
								children: area.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-1 list-disc pl-5 text-sm leading-relaxed",
								children: area.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: point }, point))
							})] }, area.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-extrabold tracking-widest uppercase",
							children: "Competencias"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-4 sm:grid-cols-2",
							children: [SKILL_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-bold",
								children: group.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm",
								children: group.points.join(" · ")
							})] }, group.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-bold",
									children: "Informática & Software"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: [...SOFTWARE_SKILLS.left, ...SOFTWARE_SKILLS.right].join(" · ")
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-extrabold tracking-widest uppercase",
							children: "Aptitudes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: TRAITS.map((trait) => trait.title).join(" · ")
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        .cv-sheet, .cv-sheet a { color: #07140f; }
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .cv-sheet { margin: 0; max-width: none; box-shadow: none; }
        }
      ` })
		]
	});
}
//#endregion
export { CvPage as component };
