import { i as Habilidades } from "./pages-ZqDcYkLc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/habilidades-CuQku5uS.js
var SplitComponent = Habilidades;
//#endregion
export { SplitComponent as component };
