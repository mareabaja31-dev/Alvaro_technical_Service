import { createFileRoute } from "@tanstack/react-router";
import { Gracias } from "@/portfolio/pages";

export const Route = createFileRoute("/gracias")({
  head: () => ({ meta: [{ title: "Gracias — Álvaro García-Aparicio Rey" }] }),
  component: Gracias,
});
