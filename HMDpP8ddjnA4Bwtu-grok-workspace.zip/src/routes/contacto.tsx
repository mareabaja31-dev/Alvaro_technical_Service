import { createFileRoute } from "@tanstack/react-router";
import { Contacto } from "@/portfolio/pages";

type ContactSearch = { asunto?: string };

export const Route = createFileRoute("/contacto")({
  validateSearch: (search: Record<string, unknown>): ContactSearch => {
    if (typeof search.asunto === "string" && search.asunto.length > 0) return { asunto: search.asunto };
    return {};
  },
  head: () => ({ meta: [{ title: "Contacto — Álvaro García-Aparicio Rey" }] }),
  component: ContactoPage,
});

function ContactoPage() {
  const { asunto } = Route.useSearch();
  return <Contacto initialSubject={asunto ?? ""} />;
}
