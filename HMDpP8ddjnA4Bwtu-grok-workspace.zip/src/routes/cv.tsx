import { createFileRoute, Link } from "@tanstack/react-router";
import { AREAS, PROFILE, SKILL_GROUPS, SOFTWARE_SKILLS, TRAITS } from "@/portfolio/data";

export const Route = createFileRoute("/cv")({
  head: () => ({ meta: [{ title: "CV — Álvaro García-Aparicio Rey" }] }),
  component: CvPage,
});

function CvPage() {
  return (
    <main className="min-h-screen bg-bg text-fg">
      <div className="no-print sticky top-0 z-10 border-b border-line bg-bg/90 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-5 py-3">
          <Link to="/" className="text-sm font-bold text-accent">
            ← Volver al portfolio
          </Link>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex min-h-11 items-center rounded-full bg-accent px-5 text-sm font-extrabold text-ink"
          >
            Guardar PDF
          </button>
        </div>
      </div>
      <article className="cv-sheet mx-auto my-8 max-w-3xl bg-fg px-6 py-10 text-ink sm:px-12">
        <header className="border-b border-ink/15 pb-6">
          <h1 className="text-3xl font-extrabold tracking-tight">{PROFILE.name}</h1>
          <p className="mt-2 text-sm font-extrabold tracking-widest text-ink/70 uppercase">{PROFILE.kicker}</p>
          <p className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm">
            <a href={PROFILE.phoneHref}>{PROFILE.phoneDisplay}</a>
            <a href={`mailto:${PROFILE.email}`}>{PROFILE.email}</a>
            <a href={PROFILE.linkedin}>LinkedIn</a>
            <a href={PROFILE.whatsapp}>WhatsApp</a>
          </p>
        </header>
        <section className="mt-6">
          <h2 className="text-sm font-extrabold tracking-widest uppercase">Perfil</h2>
          <p className="mt-2 text-sm leading-relaxed">
            Perfil multidisciplinar que combina ingeniería técnica sobre el terreno con soluciones digitales. Experiencia
            en electromecánica de automóviles, montaje eléctrico de turbinas eólicas y desarrollo de software con
            automatización e inteligencia artificial.
          </p>
        </section>
        <section className="mt-6">
          <h2 className="text-sm font-extrabold tracking-widest uppercase">Áreas profesionales</h2>
          <div className="mt-3 space-y-4">
            {AREAS.map((area) => (
              <div key={area.id}>
                <h3 className="text-base font-bold">{area.title}</h3>
                <ul className="mt-1 list-disc pl-5 text-sm leading-relaxed">
                  {area.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
        <section className="mt-6">
          <h2 className="text-sm font-extrabold tracking-widest uppercase">Competencias</h2>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            {SKILL_GROUPS.map((group) => (
              <div key={group.id}>
                <h3 className="text-sm font-bold">{group.title}</h3>
                <p className="mt-1 text-sm">{group.points.join(" · ")}</p>
              </div>
            ))}
            <div className="sm:col-span-2">
              <h3 className="text-sm font-bold">Informática & Software</h3>
              <p className="mt-1 text-sm">{[...SOFTWARE_SKILLS.left, ...SOFTWARE_SKILLS.right].join(" · ")}</p>
            </div>
          </div>
        </section>
        <section className="mt-6">
          <h2 className="text-sm font-extrabold tracking-widest uppercase">Aptitudes</h2>
          <p className="mt-2 text-sm">{TRAITS.map((trait) => trait.title).join(" · ")}</p>
        </section>
      </article>
      <style>{`
        .cv-sheet, .cv-sheet a { color: #07140f; }
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .cv-sheet { margin: 0; max-width: none; box-shadow: none; }
        }
      `}</style>
    </main>
  );
}
