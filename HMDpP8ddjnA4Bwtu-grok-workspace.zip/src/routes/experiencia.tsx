import { createFileRoute } from "@tanstack/react-router";
import { Experiencia } from "@/portfolio/pages";

export const Route = createFileRoute("/experiencia")({
  head: () => ({ meta: [{ title: "Experiencia — Álvaro García-Aparicio Rey" }] }),
  component: Experiencia,
});
