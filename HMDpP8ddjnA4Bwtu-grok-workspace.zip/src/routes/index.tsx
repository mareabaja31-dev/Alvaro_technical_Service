import { createFileRoute } from "@tanstack/react-router";
import { Inicio } from "@/portfolio/pages";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Inicio — Álvaro García-Aparicio Rey" }] }),
  component: Inicio,
});
