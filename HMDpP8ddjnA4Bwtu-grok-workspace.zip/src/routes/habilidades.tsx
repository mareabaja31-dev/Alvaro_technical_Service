import { createFileRoute } from "@tanstack/react-router";
import { Habilidades } from "@/portfolio/pages";

export const Route = createFileRoute("/habilidades")({
  head: () => ({ meta: [{ title: "Habilidades — Álvaro García-Aparicio Rey" }] }),
  component: Habilidades,
});
