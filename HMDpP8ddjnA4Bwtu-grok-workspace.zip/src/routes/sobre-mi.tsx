import { createFileRoute } from "@tanstack/react-router";
import { SobreMi } from "@/portfolio/pages";

export const Route = createFileRoute("/sobre-mi")({
  head: () => ({ meta: [{ title: "Sobre mí — Álvaro García-Aparicio Rey" }] }),
  component: SobreMi,
});
