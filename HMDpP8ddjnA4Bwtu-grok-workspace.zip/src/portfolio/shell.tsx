import { useEffect, useRef, useState } from "react";
import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { Download, Menu, X } from "lucide-react";
import { Background } from "@/portfolio/background";
import { NAV, PAGE_ORDER, PROFILE, pageFromPath, type PageId } from "@/portfolio/data";

function goTo(navigate: ReturnType<typeof useNavigate>, id: PageId) {
  if (id === "inicio") navigate({ to: "/" });
  else if (id === "sobre-mi") navigate({ to: "/sobre-mi" });
  else if (id === "experiencia") navigate({ to: "/experiencia" });
  else if (id === "habilidades") navigate({ to: "/habilidades" });
  else if (id === "contacto") navigate({ to: "/contacto" });
  else navigate({ to: "/gracias" });
}

export function Shell() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const page = pageFromPath(pathname);
  const navigate = useNavigate();
  const scroller = useRef<HTMLDivElement>(null);
  const [menu, setMenu] = useState(false);
  const lock = useRef(false);
  const pageRef = useRef(page);
  pageRef.current = page;

  useEffect(() => {
    setMenu(false);
    scroller.current?.scrollTo({ top: 0 });
  }, [page]);

  useEffect(() => {
    const root = document.documentElement;
    const prev = root.style.overflow;
    root.style.overflow = "hidden";
    return () => {
      root.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    const sc = () => scroller.current;
    const atEdge = (direction: 1 | -1) => {
      const node = sc();
      if (!node) return false;
      const atTop = node.scrollTop <= 1;
      const atBottom = node.scrollTop + node.clientHeight >= node.scrollHeight - 2;
      return direction > 0 ? atBottom : atTop;
    };
    const shift = (direction: 1 | -1, force = false) => {
      if (lock.current || menu) return false;
      if (document.querySelector("[data-modal]")) return false;
      if (!force && !atEdge(direction)) return false;
      const index = PAGE_ORDER.indexOf(pageRef.current);
      const next = PAGE_ORDER[index + direction];
      if (!next) return false;
      lock.current = true;
      window.setTimeout(() => {
        lock.current = false;
      }, 700);
      goTo(navigate, next);
      return true;
    };

    let acc = 0;
    const onWheel = (event: WheelEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("textarea, input, select, [data-modal]")) return;
      const node = sc();
      if (!node) return;
      const atTop = node.scrollTop <= 1;
      const atBottom = node.scrollTop + node.clientHeight >= node.scrollHeight - 2;
      const down = event.deltaY > 0;
      if ((down && !atBottom) || (!down && !atTop)) {
        acc = 0;
        return;
      }
      if (lock.current) {
        event.preventDefault();
        return;
      }
      acc += event.deltaY;
      if (Math.abs(acc) < 70) return;
      event.preventDefault();
      acc = 0;
      shift(down ? 1 : -1);
    };

    let startY = 0;
    let startScroll = 0;
    const onTouchStart = (event: TouchEvent) => {
      const touch = event.touches[0];
      if (!touch) return;
      startY = touch.clientY;
      startScroll = sc()?.scrollTop ?? 0;
    };
    const onTouchEnd = (event: TouchEvent) => {
      const touch = event.changedTouches[0];
      const node = sc();
      if (!touch || !node) return;
      if (Math.abs(node.scrollTop - startScroll) > 8) return;
      const dy = startY - touch.clientY;
      if (Math.abs(dy) < 64) return;
      shift(dy > 0 ? 1 : -1);
    };

    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (event.key === "Escape") setMenu(false);
      if (event.key === "ArrowDown" || event.key === "PageDown") {
        if (shift(1, true)) event.preventDefault();
      }
      if (event.key === "ArrowUp" || event.key === "PageUp") {
        if (shift(-1, true)) event.preventDefault();
      }
    };

    window.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("wheel", onWheel);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchend", onTouchEnd);
      window.removeEventListener("keydown", onKey);
    };
  }, [menu, navigate]);

  const label = NAV.find((item) => item.id === page)?.label ?? "Gracias";

  return (
    <>
      <Background page={page} />
      <header className="site-header fixed inset-x-0 top-0 z-40 border-b border-line/80 bg-bg/55 backdrop-blur-xl">
        <div className="mx-auto flex h-full max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" className="min-w-0 text-left">
            <span className="block truncate text-sm font-extrabold text-fg sm:text-base">{PROFILE.name}</span>
            <span className="kicker hidden text-accent sm:block">{PROFILE.kicker}</span>
          </Link>
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Secciones">
            {NAV.map((item) => (
              <Link
                key={item.id}
                to={item.href}
                aria-current={page === item.id ? "page" : undefined}
                className={`nav-link ${page === item.id ? "is-active" : ""}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/cv"
              className="inline-flex min-h-11 items-center gap-2 rounded-full border border-accent/70 px-3 text-xs font-extrabold text-accent transition hover:bg-accent hover:text-ink sm:px-4 sm:text-sm"
            >
              <span className="hidden sm:inline">Descargar CV</span>
              <Download className="size-4" />
            </Link>
            <button
              type="button"
              className="grid size-11 place-items-center rounded-full border border-line text-fg lg:hidden"
              aria-expanded={menu}
              aria-label={menu ? "Cerrar menú" : "Abrir menú"}
              onClick={() => setMenu((open) => !open)}
            >
              {menu ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
      </header>
      {menu ? (
        <div className="fixed inset-0 z-30 bg-bg/95 px-8 pt-28 lg:hidden">
          <nav className="flex flex-col gap-2" aria-label="Secciones">
            {NAV.map((item) => (
              <Link
                key={item.id}
                to={item.href}
                className="min-h-12 text-2xl font-extrabold text-fg"
                aria-current={page === item.id ? "page" : undefined}
              >
                {item.label}
              </Link>
            ))}
            <Link to="/gracias" className="min-h-12 text-2xl font-extrabold text-muted">
              Gracias
            </Link>
          </nav>
        </div>
      ) : null}
      <div ref={scroller} className="scroller">
        <div key={page} className="page-in page-frame">
          <p className="sr-only" aria-live="polite">
            Sección {label}
          </p>
          <Outlet />
        </div>
      </div>
    </>
  );
}
