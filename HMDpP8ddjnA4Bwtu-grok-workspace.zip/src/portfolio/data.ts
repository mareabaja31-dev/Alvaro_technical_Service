export const PAGE_ORDER = [
  "inicio",
  "sobre-mi",
  "experiencia",
  "habilidades",
  "contacto",
  "gracias",
] as const;

export type PageId = (typeof PAGE_ORDER)[number];

export const NAV: { id: PageId; label: string; href: "/" | "/sobre-mi" | "/experiencia" | "/habilidades" | "/contacto" }[] = [
  { id: "inicio", label: "Inicio", href: "/" },
  { id: "sobre-mi", label: "Sobre mí", href: "/sobre-mi" },
  { id: "experiencia", label: "Experiencia", href: "/experiencia" },
  { id: "habilidades", label: "Habilidades", href: "/habilidades" },
  { id: "contacto", label: "Contacto", href: "/contacto" },
];

export function pageFromPath(pathname: string): PageId {
  const clean = pathname.replace(/\/$/, "") || "/";
  switch (clean) {
    case "/sobre-mi":
      return "sobre-mi";
    case "/experiencia":
      return "experiencia";
    case "/habilidades":
      return "habilidades";
    case "/contacto":
      return "contacto";
    case "/gracias":
      return "gracias";
    default:
      return "inicio";
  }
}

export const PROFILE = {
  name: "Álvaro García-Aparicio Rey",
  kicker: "Mecánica · Electrónica · Informática",
  phoneDisplay: "+34 659 597 291",
  phoneHref: "tel:+34659597291",
  email: "alvarogar31@gmail.com",
  linkedin: "https://www.linkedin.com/in/alvaro-garcia-aparicio-rey-576821290",
  whatsapp: "https://wa.me/34659597291",
};

export const SUBJECTS = [
  "Oportunidad laboral",
  "Electromecánica / Automoción",
  "Montaje eólico / Electricidad",
  "Software / Automatización / IA",
  "Otro asunto",
] as const;

export type Area = {
  id: "auto" | "eolica" | "digital";
  title: string;
  image: string;
  alt: string;
  subject: (typeof SUBJECTS)[number];
  points: string[];
  detail: string;
};

export const AREAS: Area[] = [
  {
    id: "auto",
    title: "Electromecánico de Automóviles & Automatización",
    image: "/photos/auto.jpg",
    alt: "Deportivo negro en taller con diagnóstico electrónico",
    subject: "Electromecánica / Automoción",
    points: [
      "Reparaciones y Mantenimiento",
      "Adaptaciones Técnicas",
      "Automatización de Vehículos y Procesos de Negocio",
    ],
    detail:
      "Trabajo de electromecánica sobre el vehículo y sobre el proceso: diagnosis, reparación, mantenimiento y adaptaciones técnicas. Cuando un paso se repite, lo automatizo para que el taller o el negocio gane fiabilidad y tiempo.",
  },
  {
    id: "eolica",
    title: "Técnico de Montaje de Turbinas Eólicas (Electricista)",
    image: "/photos/wind.jpg",
    alt: "Técnico sobre la góndola de un aerogenerador al atardecer",
    subject: "Montaje eólico / Electricidad",
    points: [
      "Montaje de Estructuras",
      "Cableado Industrial Especializado",
      "Trabajos en Altura (PRL)",
      "Verificaciones Eléctricas",
    ],
    detail:
      "Montaje de turbinas en campo, con el oficio de electricista: estructuras, cableado industrial, trabajo en altura con PRL y verificaciones eléctricas antes de dejar la máquina en servicio.",
  },
  {
    id: "digital",
    title: "Informática, Desarrollo & Inteligencia Artificial",
    image: "/photos/code.jpg",
    alt: "Puesto de desarrollo con monitores y una red neuronal luminosa",
    subject: "Software / Automatización / IA",
    points: [
      "Desarrollo Web & Frontend/Backend",
      "Python & JavaScript",
      "Automatización de Recursos",
      "Integración de IA",
    ],
    detail:
      "Desarrollo web, Python y JavaScript, automatización de recursos e integración de inteligencia artificial aplicada a un problema concreto: menos tarea manual, más criterio técnico.",
  },
];

export const TRAITS = [
  { title: "Versatilidad técnica", icon: "layers" },
  { title: "Resolución de problemas", icon: "brain" },
  { title: "Trabajo en equipo", icon: "users" },
  { title: "Orientación a resultados", icon: "target" },
] as const;

export const SKILL_GROUPS = [
  {
    id: "mech",
    title: "Electromecánica & Mantenimiento",
    image: "/photos/mech.jpg",
    alt: "Detalle de componentes mecánicos de un motor",
    points: [
      "Diagnosis",
      "Reparaciones",
      "Mantenimiento Preventivo/Correctivo",
      "Adaptaciones",
      "Automatización Vehicular",
    ],
  },
  {
    id: "wind",
    title: "Energía Eólica & Electricidad",
    image: "/photos/farm.jpg",
    alt: "Parque eólico al anochecer",
    points: ["Montaje de Turbinas", "Cableado Industrial", "Trabajos en Altura (PRL)", "Verificaciones Eléctricas"],
  },
] as const;

export const SOFTWARE_SKILLS = {
  left: ["Desarrollo Web", "Python", "JavaScript"],
  right: ["Automatización de Recursos", "Integración de IA", "Soporte Técnico"],
};
