import { useEffect, useId, useRef, useState, type FormEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { Link } from "@tanstack/react-router";
import {
  ArrowDown,
  ArrowUp,
  Brain,
  Car,
  Code,
  Cpu,
  ExternalLink,
  Layers,
  Linkedin,
  Mail,
  Mouse,
  Phone,
  Send,
  Settings,
  Target,
  Users,
  Wind,
  X,
} from "lucide-react";
import { AREAS, PROFILE, SKILL_GROUPS, SOFTWARE_SKILLS, SUBJECTS, TRAITS, type Area } from "@/portfolio/data";
import { WhatsAppIcon } from "@/portfolio/icons";

function SocialRow() {
  const items = [
    {
      label: "LinkedIn",
      href: PROFILE.linkedin,
      external: true,
      icon: <Linkedin className="size-5" />,
    },
    {
      label: "WhatsApp",
      href: PROFILE.whatsapp,
      external: true,
      icon: <WhatsAppIcon className="size-5" />,
    },
    {
      label: "Llamar",
      href: PROFILE.phoneHref,
      external: false,
      icon: <Phone className="size-5" />,
    },
  ];
  return (
    <div className="flex flex-wrap gap-6">
      {items.map((item) => (
        <a
          key={item.label}
          href={item.href}
          {...(item.external ? { target: "_blank", rel: "noreferrer" } : {})}
          className="group flex min-w-16 flex-col items-center gap-2 text-xs font-semibold text-muted transition hover:text-accent"
        >
          <span className="grid size-12 place-items-center rounded-full border border-line bg-bg/50 text-fg transition group-hover:border-accent group-hover:text-accent">
            {item.icon}
          </span>
          {item.label}
        </a>
      ))}
    </div>
  );
}

const traitIcon = {
  layers: Layers,
  brain: Brain,
  users: Users,
  target: Target,
} as const;

export function Inicio() {
  return (
    <div className="flex flex-1 flex-col">
      <div className="flex flex-1 items-center px-5 py-8 sm:px-8">
        <div className="mx-auto grid w-full max-w-7xl items-center gap-10 lg:grid-cols-[1.45fr_0.55fr]">
          <div className="max-w-2xl pb-4">
            <p className="text-lg font-semibold italic text-accent">Hola, soy</p>
            <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-fg sm:text-5xl lg:text-6xl">
              {PROFILE.name}
            </h1>
            <p className="kicker mt-4 text-accent">{PROFILE.kicker}</p>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
              Un perfil multidisciplinar que combina ingeniería técnica sobre el terreno con soluciones digitales
              avanzadas.
            </p>
            <Link
              to="/experiencia"
              className="btn-glow mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-7 text-sm font-extrabold text-ink transition hover:-translate-y-0.5"
            >
              Explorar mi portfolio
              <ArrowDown className="size-4" />
            </Link>
            <div className="mt-8">
              <SocialRow />
            </div>
          </div>
          <ul className="space-y-4 lg:justify-self-end">
            {["Automoción", "Energía eólica", "Tecnología", "IA"].map((tag) => (
              <li key={tag} className="flex items-center gap-3 text-sm font-extrabold tracking-widest text-fg">
                <span className="size-2 rotate-45 bg-accent" />
                {tag.toUpperCase()}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <Link
        to="/sobre-mi"
        className="flex flex-col items-center gap-1 pb-5 text-xs font-medium text-muted transition hover:text-accent"
      >
        <Mouse className="floaty size-5 text-accent" />
        Desliza para explorar
      </Link>
    </div>
  );
}

export function SobreMi() {
  return (
    <div className="flex flex-1 items-center px-5 py-10 sm:px-8">
      <div className="mx-auto grid w-full max-w-7xl items-center gap-12 lg:grid-cols-2">
        <div>
          <p className="kicker text-accent">Sobre mí</p>
          <h2 className="mt-3 text-3xl font-extrabold leading-tight text-fg sm:text-5xl">
            Más que un perfil técnico,
            <br />
            una visión completa.
          </h2>
          <p className="mt-6 max-w-xl text-sm leading-relaxed text-muted sm:text-base">
            Soy una persona apasionada por la tecnología, la mecánica y la innovación. Mi formación y experiencia me
            permiten abordar proyectos complejos en distintos entornos, desde el montaje de turbinas eólicas y la
            electromecánica industrial, hasta el desarrollo de soluciones informáticas y la integración de Inteligencia
            Artificial.
          </p>
          <ul className="mt-8 space-y-4">
            {TRAITS.map((trait) => {
              const Icon = traitIcon[trait.icon];
              return (
                <li key={trait.title} className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-full border border-accent/40 bg-accent/10 text-accent">
                    <Icon className="size-4" />
                  </span>
                  <span className="text-sm font-bold text-fg">{trait.title}</span>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="hud mx-auto w-full max-w-md overflow-hidden">
          <div className="relative">
            <img
              src="/photos/about.jpg"
              alt="Técnico de energía eólica frente a un parque de turbinas al atardecer"
              className="aspect-3/4 w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent" />
            <p className="glass absolute right-4 bottom-4 left-4 border-l-4 border-l-accent px-4 py-3 text-sm font-bold text-accent">
              De la ingeniería en el campo a la innovación digital.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

const areaIcon = {
  auto: Car,
  eolica: Wind,
  digital: Cpu,
} as const;

export function Experiencia() {
  const [open, setOpen] = useState<Area | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className="flex flex-1 items-center px-5 py-10 sm:px-8">
      <div className="mx-auto w-full max-w-7xl">
        <p className="kicker text-accent">Experiencia profesional</p>
        <h2 className="mt-3 max-w-3xl text-3xl font-extrabold leading-tight text-fg sm:text-5xl">
          Tres áreas, un mismo objetivo:
          <br />
          resolver, mejorar, innovar.
        </h2>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {AREAS.map((area) => {
            const Icon = areaIcon[area.id];
            return (
              <article key={area.id} className="glass glass-hover flex flex-col overflow-hidden transition">
                <div className="relative h-44">
                  <img src={area.image} alt={area.alt} className="h-full w-full object-cover" />
                  <span className="absolute bottom-3 left-3 grid size-10 place-items-center rounded-lg bg-bg/80 text-accent ring-1 ring-accent/40">
                    <Icon className="size-5" />
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="text-lg font-bold leading-snug text-fg">{area.title}</h3>
                  <ul className="mt-4 flex-1 space-y-2 text-sm text-muted">
                    {area.points.map((point) => (
                      <li key={point} className="flex gap-2">
                        <span className="mt-2 size-1 shrink-0 rounded-full bg-accent" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    type="button"
                    onClick={() => setOpen(area)}
                    className="mt-5 inline-flex min-h-11 items-center text-sm font-bold text-accent"
                  >
                    Ver más →
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </div>
      {open && typeof document !== "undefined"
        ? createPortal(
            <div
              data-modal
              className="fixed inset-0 z-50 flex items-end justify-center bg-bg/75 p-4 backdrop-blur-sm sm:items-center"
              onClick={() => setOpen(null)}
            >
              <div
                role="dialog"
                aria-modal="true"
                aria-labelledby={titleId}
                className="glass max-h-[88vh] w-full max-w-3xl overflow-y-auto"
                onClick={(event) => event.stopPropagation()}
              >
                <div className="relative h-56 sm:h-72">
                  <img src={open.image} alt="" className="h-full w-full object-cover" />
                  <button
                    ref={closeRef}
                    type="button"
                    onClick={() => setOpen(null)}
                    aria-label="Cerrar"
                    className="absolute top-3 right-3 grid size-11 place-items-center rounded-full bg-bg/80 text-fg"
                  >
                    <X className="size-5" />
                  </button>
                </div>
                <div className="p-6 sm:p-8">
                  <h3 id={titleId} className="text-2xl font-extrabold text-fg">
                    {open.title}
                  </h3>
                  <p className="mt-4 text-sm leading-relaxed text-muted sm:text-base">{open.detail}</p>
                  <ul className="mt-5 space-y-2 text-sm text-fg">
                    {open.points.map((point) => (
                      <li key={point} className="flex gap-2">
                        <span className="mt-2 size-1 shrink-0 rounded-full bg-accent" />
                        {point}
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/contacto"
                    search={{ asunto: open.subject }}
                    className="btn-glow mt-6 inline-flex min-h-12 items-center rounded-full bg-accent px-6 text-sm font-extrabold text-ink"
                  >
                    Contactar sobre esto
                  </Link>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}

function SkillCard({
  icon,
  title,
  points,
  image,
  alt,
}: {
  icon: ReactNode;
  title: string;
  points: readonly string[];
  image: string;
  alt: string;
}) {
  return (
    <article className="glass relative overflow-hidden">
      <img src={image} alt={alt} className="absolute inset-0 h-full w-full object-cover opacity-45" />
      <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/85 to-bg/25" />
      <div className="relative flex gap-4 p-6">
        <span className="grid size-12 shrink-0 place-items-center rounded-xl border border-accent/40 bg-bg/60 text-accent">
          {icon}
        </span>
        <div>
          <h3 className="text-base font-bold text-fg">{title}</h3>
          <ul className="mt-3 space-y-1.5 text-sm text-muted">
            {points.map((point) => (
              <li key={point}>• {point}</li>
            ))}
          </ul>
        </div>
      </div>
    </article>
  );
}

export function Habilidades() {
  return (
    <div className="flex flex-1 items-center px-5 py-10 sm:px-8">
      <div className="mx-auto w-full max-w-7xl">
        <p className="kicker text-accent">Habilidades y competencias</p>
        <h2 className="mt-3 text-3xl font-extrabold leading-tight text-fg sm:text-5xl">
          Conocimiento técnico,
          <br />
          experiencia real.
        </h2>
        <div className="mt-10 grid gap-5 md:grid-cols-2">
          <SkillCard
            icon={<Settings className="size-6" />}
            title={SKILL_GROUPS[0].title}
            points={SKILL_GROUPS[0].points}
            image={SKILL_GROUPS[0].image}
            alt={SKILL_GROUPS[0].alt}
          />
          <SkillCard
            icon={<Wind className="size-6" />}
            title={SKILL_GROUPS[1].title}
            points={SKILL_GROUPS[1].points}
            image={SKILL_GROUPS[1].image}
            alt={SKILL_GROUPS[1].alt}
          />
        </div>
        <article className="glass mt-5 grid overflow-hidden md:grid-cols-[1.2fr_0.8fr]">
          <div className="flex gap-4 p-6">
            <span className="grid size-12 shrink-0 place-items-center rounded-xl border border-accent/40 bg-accent/10 text-accent">
              <Code className="size-6" />
            </span>
            <div>
              <h3 className="text-base font-bold text-fg">Informática & Software</h3>
              <div className="mt-4 grid gap-4 text-sm text-muted sm:grid-cols-2">
                <ul className="space-y-1.5">
                  {SOFTWARE_SKILLS.left.map((item) => (
                    <li key={item}>• {item}</li>
                  ))}
                </ul>
                <ul className="space-y-1.5">
                  {SOFTWARE_SKILLS.right.map((item) => (
                    <li key={item}>• {item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
          <div className="relative min-h-40">
            <img
              src="/photos/laptop.jpg"
              alt="Portátil con código en un escritorio oscuro"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/20 to-transparent" />
          </div>
        </article>
      </div>
    </div>
  );
}

export function Contacto({ initialSubject = "" }: { initialSubject?: string }) {
  const [subject, setSubject] = useState(initialSubject);
  const [fileName, setFileName] = useState("Ningún archivo seleccionado");
  const [fileError, setFileError] = useState("");
  const [sent, setSent] = useState(false);
  const [mailto, setMailto] = useState("");

  useEffect(() => {
    if (initialSubject) setSubject(initialSubject);
  }, [initialSubject]);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();
    const file = (data.get("attachment") as File | null)?.name;
    const chosen = subject || "Contacto desde el portfolio";
    const body = [
      `Nombre: ${name}`,
      `Email: ${email}`,
      `Asunto: ${chosen}`,
      "",
      message,
      "",
      file ? `Archivo que quiero adjuntar: ${file}` : "Sin archivo adjunto.",
    ].join("\n");
    const href = `mailto:${PROFILE.email}?subject=${encodeURIComponent(chosen)}&body=${encodeURIComponent(body)}`;
    setMailto(href);
    setSent(true);
    window.location.href = href;
  }

  return (
    <div className="flex flex-1 items-center px-5 py-10 sm:px-8">
      <div className="mx-auto grid w-full max-w-7xl items-start gap-12 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="kicker text-accent">Contacto</p>
          <h2 className="mt-3 text-3xl font-extrabold leading-tight text-fg sm:text-5xl">
            Hablemos de tu próximo proyecto.
          </h2>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-muted sm:text-base">
            ¿Tienes una oportunidad, un proyecto o simplemente quieres saber más? Estoy disponible para cualquier
            consulta.
          </p>
          <div className="mt-8 space-y-5">
            <a href={PROFILE.phoneHref} className="flex items-center gap-4">
              <span className="grid size-12 place-items-center rounded-full border border-accent/40 text-accent">
                <Phone className="size-5" />
              </span>
              <span>
                <span className="block text-xs font-bold tracking-wider text-muted uppercase">Teléfono</span>
                <span className="text-sm font-bold text-fg">{PROFILE.phoneDisplay}</span>
              </span>
            </a>
            <a href={`mailto:${PROFILE.email}`} className="flex items-center gap-4">
              <span className="grid size-12 place-items-center rounded-full border border-accent/40 text-accent">
                <Mail className="size-5" />
              </span>
              <span>
                <span className="block text-xs font-bold tracking-wider text-muted uppercase">Email</span>
                <span className="text-sm font-bold text-fg">{PROFILE.email}</span>
              </span>
            </a>
            <a href={PROFILE.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-4">
              <span className="grid size-12 place-items-center rounded-full border border-accent/40 text-accent">
                <Linkedin className="size-5" />
              </span>
              <span>
                <span className="block text-xs font-bold tracking-wider text-muted uppercase">LinkedIn</span>
                <span className="text-sm font-bold text-fg">Ver perfil profesional</span>
              </span>
            </a>
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="glass p-5 sm:p-8">
            {sent ? (
              <div className="py-8 text-center">
                <p className="kicker text-accent">Mensaje preparado</p>
                <h3 className="mt-3 text-2xl font-extrabold text-fg">Tu correo está listo para enviarse.</h3>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted">
                  Se abre el programa de correo con el mensaje dirigido a Álvaro. Si llevas un archivo, adjúntalo allí
                  antes de enviar. Si no se abrió solo, usa el botón.
                </p>
                <a
                  href={mailto}
                  className="btn-glow mt-6 inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-6 text-sm font-extrabold text-ink"
                >
                  <Send className="size-4" />
                  Abrir correo
                </a>
                <button
                  type="button"
                  onClick={() => setSent(false)}
                  className="mt-4 block w-full text-sm font-semibold text-muted hover:text-accent"
                >
                  Escribir otro mensaje
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <label className="block text-xs font-bold text-muted">
                    Nombre completo
                    <input required name="name" autoComplete="name" placeholder="Tu nombre completo" className="field mt-1" />
                  </label>
                  <label className="block text-xs font-bold text-muted">
                    Correo electrónico
                    <input
                      required
                      type="email"
                      name="email"
                      autoComplete="email"
                      placeholder="tu@email.com"
                      className="field mt-1"
                    />
                  </label>
                </div>
                <label className="block text-xs font-bold text-muted">
                  Asunto / Área de interés
                  <select
                    name="subject"
                    value={subject}
                    onChange={(event) => setSubject(event.target.value)}
                    className="field mt-1"
                  >
                    <option value="">Selecciona una opción</option>
                    {SUBJECTS.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block text-xs font-bold text-muted">
                  Mensaje
                  <textarea
                    required
                    name="message"
                    rows={4}
                    placeholder="Escribe tu mensaje..."
                    className="field mt-1 resize-y"
                  />
                </label>
                <div>
                  <p className="text-xs font-bold text-muted">Adjuntar archivo</p>
                  <p className="mt-1 text-xs text-muted">PDF, imágenes, especificaciones... (Máx. 10 MB)</p>
                  <div className="mt-2 flex flex-wrap items-center gap-3">
                    <label className="inline-flex min-h-11 cursor-pointer items-center rounded-lg border border-accent/40 bg-accent/15 px-4 text-xs font-bold text-accent transition hover:bg-accent hover:text-ink">
                      Seleccionar archivo
                      <input
                        type="file"
                        name="attachment"
                        className="sr-only"
                        onChange={(event) => {
                          const file = event.target.files?.[0];
                          if (!file) {
                            setFileName("Ningún archivo seleccionado");
                            setFileError("");
                            return;
                          }
                          if (file.size > 10 * 1024 * 1024) {
                            setFileError("El archivo supera 10 MB.");
                            setFileName("Ningún archivo seleccionado");
                            event.target.value = "";
                            return;
                          }
                          setFileError("");
                          setFileName(file.name);
                        }}
                      />
                    </label>
                    <span className="text-xs text-muted">{fileName}</span>
                  </div>
                  {fileError ? <p className="mt-2 text-xs font-semibold text-accent">{fileError}</p> : null}
                </div>
                <button
                  type="submit"
                  className="btn-glow inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-accent text-sm font-extrabold text-ink"
                >
                  <Send className="size-4" />
                  Enviar mensaje
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Gracias() {
  const year = new Date().getFullYear();
  return (
    <div className="relative flex flex-1 flex-col">
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-16 text-center">
        <h2 className="text-4xl font-extrabold text-fg sm:text-5xl">{PROFILE.name}</h2>
        <p className="kicker mt-4 text-accent">{PROFILE.kicker}</p>
        <h3 className="mt-10 text-2xl font-bold text-fg sm:text-3xl">Gracias por tu tiempo</h3>
        <p className="mt-3 text-sm text-muted">Si tienes cualquier duda, no dudes en contactarme.</p>
        <div className="mt-8 flex items-center gap-3">
          <a
            href={PROFILE.linkedin}
            target="_blank"
            rel="noreferrer"
            aria-label="LinkedIn"
            className="grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent"
          >
            <Linkedin className="size-5" />
          </a>
          <a
            href={PROFILE.whatsapp}
            target="_blank"
            rel="noreferrer"
            aria-label="WhatsApp"
            className="grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent"
          >
            <WhatsAppIcon className="size-5" />
          </a>
          <a
            href={PROFILE.phoneHref}
            aria-label="Llamar"
            className="grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent"
          >
            <Phone className="size-5" />
          </a>
          <a
            href={`mailto:${PROFILE.email}`}
            aria-label="Email"
            className="grid size-12 place-items-center rounded-full border border-line bg-bg/60 text-fg transition hover:border-accent hover:text-accent"
          >
            <Mail className="size-5" />
          </a>
        </div>
      </div>
      <Link
        to="/"
        aria-label="Volver al inicio"
        className="absolute right-5 bottom-20 grid size-12 place-items-center rounded-full border border-line bg-bg/70 text-accent transition hover:bg-accent hover:text-ink"
      >
        <ArrowUp className="size-5" />
      </Link>
      <footer className="flex flex-col items-center justify-between gap-3 border-t border-line/80 px-6 py-4 text-xs text-muted sm:flex-row">
        <p>© {year} {PROFILE.name}. Todos los derechos reservados.</p>
        <a href={PROFILE.linkedin} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-accent">
          LinkedIn
          <ExternalLink className="size-3" />
        </a>
      </footer>
    </div>
  );
}
