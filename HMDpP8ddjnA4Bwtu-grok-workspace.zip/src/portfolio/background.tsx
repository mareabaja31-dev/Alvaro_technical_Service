import { useEffect, useRef } from "react";
import type { PageId } from "@/portfolio/data";

const SCENES: { id: PageId; src: string; position: string }[] = [
  { id: "inicio", src: "/photos/hero.jpg", position: "center center" },
  { id: "sobre-mi", src: "/photos/farm.jpg", position: "right center" },
  { id: "experiencia", src: "/photos/hero.jpg", position: "center top" },
  { id: "habilidades", src: "/photos/code.jpg", position: "right center" },
  { id: "contacto", src: "/photos/earth.jpg", position: "left center" },
  { id: "gracias", src: "/photos/thanks.jpg", position: "center center" },
];

const VEIL: PageId[] = ["inicio", "sobre-mi", "experiencia", "habilidades", "contacto", "gracias"];

const INTENSITY: Record<PageId, number> = {
  inicio: 0.72,
  "sobre-mi": 0.8,
  experiencia: 1,
  habilidades: 0.9,
  contacto: 0.85,
  gracias: 0.62,
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  el: SVGCircleElement;
};

export function Background({ page }: { page: PageId }) {
  const svgRef = useRef<SVGSVGElement>(null);
  const shiftRef = useRef<HTMLDivElement>(null);
  const intensityRef = useRef(INTENSITY[page]);
  intensityRef.current = INTENSITY[page];

  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const ns = "http://www.w3.org/2000/svg";
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const gradId = `cursor-glow-${Math.random().toString(36).slice(2, 8)}`;

    const defs = document.createElementNS(ns, "defs");
    const grad = document.createElementNS(ns, "radialGradient");
    grad.id = gradId;
    const stopA = document.createElementNS(ns, "stop");
    stopA.setAttribute("offset", "0%");
    stopA.setAttribute("stop-color", "rgb(0, 242, 195)");
    stopA.setAttribute("stop-opacity", "0.35");
    const stopB = document.createElementNS(ns, "stop");
    stopB.setAttribute("offset", "100%");
    stopB.setAttribute("stop-color", "rgb(0, 242, 195)");
    stopB.setAttribute("stop-opacity", "0");
    grad.append(stopA, stopB);
    defs.append(grad);
    const glow = document.createElementNS(ns, "circle");
    glow.setAttribute("r", "210");
    glow.setAttribute("fill", `url(#${gradId})`);
    glow.setAttribute("opacity", "0");
    svg.append(defs, glow);

    let width = window.innerWidth;
    let height = window.innerHeight;
    const count = width < 720 ? 34 : 68;
    const particles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const el = document.createElementNS(ns, "circle");
      el.setAttribute("fill", "rgb(214, 255, 244)");
      svg.append(el);
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.38,
        vy: (Math.random() - 0.5) * 0.38,
        r: Math.random() * 1.6 + 0.7,
        el,
      });
    }

    const linePool: SVGLineElement[] = [];
    for (let i = 0; i < 240; i++) {
      const line = document.createElementNS(ns, "line");
      line.setAttribute("stroke", "rgb(0, 242, 195)");
      line.style.display = "none";
      svg.append(line);
      linePool.push(line);
    }

    const mouse = { x: width * 0.72, y: height * 0.4, on: false };
    let raf = 0;

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    };

    const frame = () => {
      const intensity = intensityRef.current;
      if (!reduce) {
        for (const p of particles) {
          if (mouse.on) {
            const dx = mouse.x - p.x;
            const dy = mouse.y - p.y;
            const dist = Math.hypot(dx, dy) || 1;
            if (dist < 210) {
              const pull = ((210 - dist) / 210) * 0.05;
              p.vx += (dx / dist) * pull;
              p.vy += (dy / dist) * pull;
            }
          }
          p.vx *= 0.985;
          p.vy *= 0.985;
          if (Math.hypot(p.vx, p.vy) < 0.08) {
            p.vx += (Math.random() - 0.5) * 0.05;
            p.vy += (Math.random() - 0.5) * 0.05;
          }
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < -12) p.x = width + 12;
          if (p.x > width + 12) p.x = -12;
          if (p.y < -12) p.y = height + 12;
          if (p.y > height + 12) p.y = -12;
        }
      }

      const reach = width < 720 ? 108 : 136;
      let slot = 0;
      for (let i = 0; i < particles.length; i++) {
        const a = particles[i];
        if (!a) continue;
        a.el.setAttribute("cx", a.x.toFixed(1));
        a.el.setAttribute("cy", a.y.toFixed(1));
        a.el.setAttribute("r", a.r.toFixed(2));
        a.el.setAttribute("opacity", (0.85 * intensity).toFixed(2));
        for (let j = i + 1; j < particles.length; j++) {
          const b = particles[j];
          if (!b || slot >= linePool.length) continue;
          const dist = Math.hypot(a.x - b.x, a.y - b.y);
          if (dist < reach) {
            const line = linePool[slot];
            if (!line) continue;
            slot += 1;
            line.style.display = "";
            line.setAttribute("x1", a.x.toFixed(1));
            line.setAttribute("y1", a.y.toFixed(1));
            line.setAttribute("x2", b.x.toFixed(1));
            line.setAttribute("y2", b.y.toFixed(1));
            line.setAttribute("stroke-opacity", ((1 - dist / reach) * 0.45 * intensity).toFixed(3));
          }
        }
        if (mouse.on && slot < linePool.length) {
          const dist = Math.hypot(a.x - mouse.x, a.y - mouse.y);
          if (dist < 170) {
            const line = linePool[slot];
            if (line) {
              slot += 1;
              line.style.display = "";
              line.setAttribute("x1", a.x.toFixed(1));
              line.setAttribute("y1", a.y.toFixed(1));
              line.setAttribute("x2", mouse.x.toFixed(1));
              line.setAttribute("y2", mouse.y.toFixed(1));
              line.setAttribute("stroke-opacity", ((1 - dist / 170) * 0.7 * intensity).toFixed(3));
            }
          }
        }
      }
      for (let i = slot; i < linePool.length; i++) {
        const line = linePool[i];
        if (line) line.style.display = "none";
      }

      glow.setAttribute("cx", mouse.x.toFixed(1));
      glow.setAttribute("cy", mouse.y.toFixed(1));
      glow.setAttribute("opacity", mouse.on ? (0.85 * intensity).toFixed(2) : "0");
      raf = window.requestAnimationFrame(frame);
    };

    const onMove = (x: number, y: number) => {
      mouse.x = x;
      mouse.y = y;
      mouse.on = true;
      const shift = shiftRef.current;
      if (shift && !reduce) {
        shift.style.setProperty("--px", ((x / window.innerWidth - 0.5) * 2).toFixed(3));
        shift.style.setProperty("--py", ((y / window.innerHeight - 0.5) * 2).toFixed(3));
      }
    };

    const onPointer = (event: PointerEvent) => onMove(event.clientX, event.clientY);
    const onTouch = (event: TouchEvent) => {
      const touch = event.touches[0];
      if (touch) onMove(touch.clientX, touch.clientY);
    };
    const onLeave = () => {
      mouse.on = false;
    };

    resize();
    raf = window.requestAnimationFrame(frame);
    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", onPointer, { passive: true });
    window.addEventListener("touchmove", onTouch, { passive: true });
    window.addEventListener("pointerleave", onLeave);
    return () => {
      window.cancelAnimationFrame(raf);
      svg.replaceChildren();
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onPointer);
      window.removeEventListener("touchmove", onTouch);
      window.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-bg" aria-hidden="true">
      <div ref={shiftRef} className="photo-shift absolute inset-0">
        {SCENES.map((scene) => (
          <img
            key={scene.id}
            src={scene.src}
            alt=""
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${page === scene.id ? "opacity-100" : "opacity-0"}`}
            style={{ objectPosition: scene.position }}
          />
        ))}
      </div>
      {VEIL.map((id) => (
        <div key={id} className={`veil veil-${id} ${page === id ? "opacity-100" : "opacity-0"}`} />
      ))}
      <svg ref={svgRef} className="absolute inset-0 h-full w-full" />
    </div>
  );
}
